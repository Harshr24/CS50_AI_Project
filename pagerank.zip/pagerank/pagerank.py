import os
import random
import re
import sys

DAMPING = 0.85
SAMPLES = 10000


def main():
    if len(sys.argv) != 2:
        sys.exit("Usage: python pagerank.py corpus")
    corpus = crawl(sys.argv[1])
    ranks = sample_pagerank(corpus, DAMPING, SAMPLES)
    print(f"PageRank Results from Sampling (n = {SAMPLES})")
    for page in sorted(ranks):
        print(f"  {page}: {ranks[page]:.4f}")
    ranks = iterate_pagerank(corpus, DAMPING)
    print(f"PageRank Results from Iteration")
    for page in sorted(ranks):
        print(f"  {page}: {ranks[page]:.4f}")


def crawl(directory):
    """
    Parse a directory of HTML pages and check for links to other pages.
    Return a dictionary where each key is a page, and values are
    a list of all other pages in the corpus that are linked to by the page.
    """
    pages = dict()

    # Extract all links from HTML files
    for filename in os.listdir(directory):
        if not filename.endswith(".html"):
            continue
        with open(os.path.join(directory, filename)) as f:
            contents = f.read()
            links = re.findall(r"<a\s+(?:[^>]*?)href=\"([^\"]*)\"", contents)
            pages[filename] = set(links) - {filename}

    # Only include links to other pages in the corpus
    for filename in pages:
        pages[filename] = set(
            link for link in pages[filename]
            if link in pages
        )

    return pages

def transition_model(corpus, page, damping_factor):
    """
    Returns a probability distribution over which page to visit next.
    """
    prob_dist = {}
    all_pages = len(corpus)
    links = corpus.get(page, set())
    
    if links:
        for p in corpus:
            prob_dist[p] = (1 - damping_factor) / all_pages
        for linked_page in links:
            prob_dist[linked_page] += damping_factor / len(links)
    else:
        for p in corpus:
            prob_dist[p] = 1 / all_pages
    
    return prob_dist


def sample_pagerank(corpus, damping_factor, n):
    """
    Estimates PageRank by simulating a random surfer.
    """
    page = random.choice(list(corpus.keys()))
    pagerank = {p: 0 for p in corpus}
    
    for _ in range(n):
        pagerank[page] += 1
        model = transition_model(corpus, page, damping_factor)
        page = random.choices(list(model.keys()), weights=model.values())[0]
    
    return {p: rank / n for p, rank in pagerank.items()}


def iterate_pagerank(corpus, damping_factor, tolerance=0.001):
    """
    Computes PageRank iteratively until convergence.
    """
    N = len(corpus)
    pagerank = {p: 1 / N for p in corpus}
    new_pagerank = pagerank.copy()
    
    while True:
        for page in corpus:
            total = sum(pagerank[p] / len(corpus[p]) for p in corpus if page in corpus[p] and corpus[p])
            new_pagerank[page] = (1 - damping_factor) / N + damping_factor * total
        
        if all(abs(new_pagerank[p] - pagerank[p]) < tolerance for p in pagerank):
            break
        pagerank = new_pagerank.copy()
    
    return pagerank

if __name__ == "__main__":
    main()
