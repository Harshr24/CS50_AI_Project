from logic import *

AKnight = Symbol("A is a Knight")
AKnave = Symbol("A is a Knave")

BKnight = Symbol("B is a Knight")
BKnave = Symbol("B is a Knave")

CKnight = Symbol("C is a Knight")
CKnave = Symbol("C is a Knave")

# Puzzle 0
# A says "I am both a knight and a knave."
knowledge0 = And(
    Biconditional(AKnight, Not(AKnave)),  # A is either a knight or a knave
    Biconditional(AKnave, Not(AKnight)),  # A cannot be both
    Implication(AKnight, And(AKnight, AKnave)),  # If A is a knight, the statement must be true
    Implication(AKnave, Not(And(AKnight, AKnave)))  # If A is a knave, the statement must be false
)

# Puzzle 1
# A says "We are both knaves."
# B says nothing.
knowledge1 = And(
    Biconditional(AKnight, Not(AKnave)),
    Biconditional(BKnight, Not(BKnave)),
    Implication(AKnight, And(AKnave, BKnave)),  # If A is a knight, they are both knaves
    Implication(AKnave, Not(And(AKnave, BKnave)))  # If A is a knave, then not both are knaves
)

# Puzzle 2
# A says "We are the same kind."
# B says "We are of different kinds."
knowledge2 = And(
    Biconditional(AKnight, Not(AKnave)),
    Biconditional(BKnight, Not(BKnave)),
    Biconditional(AKnight, Biconditional(AKnight, BKnight)),  # If A is a knight, then A and B must be the same
    Biconditional(BKnight, Not(Biconditional(AKnight, BKnight)))  # If B is a knight, A and B must be different
)

# Puzzle 3
# A says either "I am a knight." or "I am a knave.", but you don't know which.
# B says "A said 'I am a knave'."
# B says "C is a knave."
# C says "A is a knight."
knowledge3 = And(
    # Basic structure: Each character is either a knight or a knave
    Biconditional(AKnight, Not(AKnave)),
    Biconditional(BKnight, Not(BKnave)),
    Biconditional(CKnight, Not(CKnave)),

    # A says either "I am a knight." or "I am a knave."
    # If A is a knight, at least one of these must be true.
    # If A is a knave, both must be false.
    Implication(AKnight, Or(AKnight, AKnave)),
    Implication(AKnave, Not(Or(AKnight, AKnave))),

    # B says "A said 'I am a knave'." 
    # If B is a knight, then A actually said "I am a knave", meaning A must be a knave.
    # If B is a knave, then A did not say "I am a knave", meaning A must be a knight.
    Biconditional(BKnight, Biconditional(AKnave, AKnight)),

    # B says "C is a knave."
    # If B is a knight, then C must be a knave.
    # If B is a knave, then C must be a knight.
    Biconditional(BKnight, CKnave),

    # C says "A is a knight."
    # If C is a knight, then A must be a knight.
    # If C is a knave, then A must be a knave.
    Biconditional(CKnight, AKnight)
)


def main():
    symbols = [AKnight, AKnave, BKnight, BKnave, CKnight, CKnave]
    puzzles = [
        ("Puzzle 0", knowledge0),
        ("Puzzle 1", knowledge1),
        ("Puzzle 2", knowledge2),
        ("Puzzle 3", knowledge3)
    ]
    for puzzle, knowledge in puzzles:
        print(puzzle)
        if len(knowledge.conjuncts) == 0:
            print("    Not yet implemented.")
        else:
            for symbol in symbols:
                if model_check(knowledge, symbol):
                    print(f"    {symbol}")


if __name__ == "__main__":
    main()
